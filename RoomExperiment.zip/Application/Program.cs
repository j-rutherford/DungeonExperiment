﻿using RoomLibrary;

namespace Application
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            var map = Room.GetMap();

            Room currentRoom = Room.GetRoomById(0);

            do
            {
            Console.WriteLine(currentRoom.RoomMap());
                Console.WriteLine(currentRoom.Description);
                Console.WriteLine("Pick a direction.");
                int direction = 0;
                switch (Console.ReadKey(true).Key)
                {
                    case ConsoleKey.UpArrow:
                        direction = currentRoom.IdNorth;
                        break;
                    case ConsoleKey.RightArrow:
                        direction = currentRoom.IdEast;
                        break;
                    case ConsoleKey.LeftArrow:
                        direction = currentRoom.IdWest;
                        break;
                    case ConsoleKey.DownArrow:
                        direction = currentRoom.IdSouth;
                        break;
                    default:
                        Console.WriteLine("Unknown");
                        direction = currentRoom.ID;
                        break;
                }//end switch
                Console.Clear();
                currentRoom = currentRoom.MoveRoom(direction);
            } while (true);

        }
    }
}