﻿namespace RoomLibrary
{
    public class Room
    {
        public int ID { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public int IdNorth { get; set; }
        public int IdEast { get; set; }
        public int IdSouth { get; set; }
        public int IdWest { get; set; }

        public Room(int id, string? name, string? description, int idNorth, int idEast, int idSouth, int idWest)
        {
            ID = id;
            Name = name;
            Description = description;
            IdNorth = idNorth;
            IdEast = idEast;
            IdSouth = idSouth;
            IdWest = idWest;
        }

        public static Room[] GetMap()
        {
            return new Room[]{
                new Room(0, "ID 0", null, 1, 4, 2, 3),
                new Room(1, "ID 1", null, 13, 5, 0, 17),
                new Room(2, "ID 2", null, 0,7,16,11),
                new Room(3, "ID 3", null, 17,0,11,15),
                new Room(4, "ID 4", null, 5,6,7,0),
                new Room(5, "ID 5", null, 8,9,4,1),
                new Room(6, "ID 6", null, 9,16,10,4),
                new Room(7, "ID 7", null, 4,10,16,2),
                new Room(8, "ID 8", null, 15,14,5,13),
                new Room(9, "ID 9", null, 14,16,6,5),
                new Room(10, "ID 10", null, 6,16,16,7),
                new Room(11, "ID 11", null, 3,2,16,15),
                new Room(12, "ID 12", null, 15,13,17,15),
                new Room(13, "ID 13", null, 15,8,1,12),
                new Room(14, "ID 14", null, 15,15,9,8),
                new Room(15, "(Inaccessable 1)", null, 15,15,15,15),
                new Room(16, "(Inaccessable 2)", null, 16,16,16,16),
                new Room(17, "Final Boss", null, 12,1,3,15),
            };
        }

        public string RoomMap()
        {
            return $"\t\tNorth:{GetRoomById(IdNorth).Name}\n\n" +
                $"West:{GetRoomById(IdWest).Name}\t\t\tEast:{GetRoomById(IdEast).Name}\n" +
                $"\t\tSouth:{GetRoomById(IdSouth).Name}";
        }

        public static Room GetRoomById(int id)
        {
            return GetMap().FirstOrDefault(x => x.ID == id);
        }

        public Room MoveRoom(int id)
        {
            if (id != 15 && id != 16)
            {
                return GetRoomById(id);
            }
            else
            {
                Console.WriteLine("You can't move that way!");
                return this;
            }
        }
    }
}